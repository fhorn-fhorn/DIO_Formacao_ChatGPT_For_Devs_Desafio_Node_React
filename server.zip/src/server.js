const app = require("./app")
const port = process.env.PORT || 3300

app.listen(port, ()=>{
    console.log(`FH: Server listening on port ${port}`)
})